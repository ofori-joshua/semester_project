#include <iostream>
using namespace std;

class Book {
public:
    string book_id;
    string book_name;
    string author_name;
    string publisher;
    float price;
    int quantity;
};

class Library {
public:
    static const int BOOKS = 10;
    Book books[BOOKS];
    int available_books;

    Library() {
        available_books = 5;
        books[0] = {"01", "PROGRAMMING", "HOD", "JUSTICE", 100.00, 160};
        books[1] = {"02", "PROBABILITY", "MR JOHN", "JOSHUA", 50.00, 160};
        books[2] = {"03", "COMP SKILLS", "MR MOHAMED", "JEFFRY", 80.00, 160};
        books[3] = {"04", "FRENCH", "MR JUSTIN", "GOLD", 15.00, 160};
        books[4] = {"05", "MATHS", "PASCAL", "AGNES", 90.00, 160};
    }

    void addBook() {
        if (available_books >= BOOKS) {
            cout << "Library is full. Cannot add more books." << endl;
            return;
        }

        Book book;
        cout << "Enter book ID: \n";
        cin >> book.book_id;
        cout << "Enter book name: \n";
        cin >> book.book_name;
        cout << "Enter author name: \n";
        cin >> book.author_name;
        cout << "Enter publisher name: \n";
        cin >> book.publisher;
        cout << "Enter quantity: \n";
        cin >> book.quantity;
        cout << "Enter price: \n";
        cin >> book.price;

        books[available_books] = book;
        available_books++;

        cout << "Book added successfully." << endl;
    }

    void displayBooks() {
        cout << "Available Books:" << endl;
        for (int i = 0; i < available_books; i++) {
            cout << "Book ID: " << books[i].book_id << endl;
            cout << "Book Name: " << books[i].book_name << endl;
            cout << "Author Name: " << books[i].author_name << endl;
            cout << "Publisher: " << books[i].publisher << endl;
            cout << "Quantity: " << books[i].quantity << endl;
            cout << "Price: " << books[i].price << endl;
            cout << endl;
        }
    }

    void modifyBook() {
        string book_id;
        cout << "Enter book ID to modify: ";
        cin >> book_id;

        for (int i = 0; i < available_books; i++) {
            if (books[i].book_id == book_id) {
                cout << "Enter new book name: ";
                cin >> books[i].book_name;
                cout << "Enter new author name: ";
                cin >> books[i].author_name;
                cout << "Enter new publisher name: ";
                cin >> books[i].publisher;
                cout << "Enter new quantity: ";
                cin >> books[i].quantity;
                cout << "Enter new price: ";
                cin >> books[i].price;

                cout << "Book modified successfully." << endl;
                return;
            }
        }

        cout << "Book not found." << endl;
    }

    void deleteBook() {
        string book_id;
        cout << "Enter book ID to delete: ";
        cin >> book_id;

        for (int i = 0; i < available_books; i++) {
            if (books[i].book_id == book_id) {
                for (int j = i; j < available_books - 1; j++) {
                    books[j] = books[j + 1];
                }

                available_books--;
                cout << "Book deleted successfully." << endl;
                return;
            }
        }

        cout << "Book not found." << endl;
    }
};

int main() {
    Library library;

    while (true) {
        cout << "\n1. Add Book" << endl;
        cout << "2. Display Books" << endl;
        cout << "3. Modify Book" << endl;
        cout << "4. Delete Book" << endl;
        cout << "5. Exit" << endl;
        cout << "\nEnter your choice: \n";

        int choice;
        cin >> choice;

        switch (choice) {
            case 1:
                library.addBook();
                break;
            case 2:
                library.displayBooks();
                break;
            case 3:
                library.modifyBook();
                break;
            case 4:
                library.deleteBook();
                break;
            case 5:
                cout <<".....................BYE BYE..................." << endl;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    }

    return 0;
}
